package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Exceptions.EmployeeNotFoundException;
import com.example.demo.Repos.Myrepo;
import com.example.demo.model.Employee;

@Service
public class MyService {
	@Autowired
	private Myrepo repo;
	public List<Employee> getAllEmployee() {
		return repo.findAll();
	}
	
	public String addEmployee(Employee employee) {
		repo.save(employee);
		return "Employee Added Successfully...";
	}
	
	public String updateEmployee(int id, Employee updateEmployee) {
		Optional<Employee> existingEmployee = repo.findById(id);
		if(existingEmployee.isPresent()) {
			Employee employee = existingEmployee.get();
			employee.getAge();
			employee.getDesig();
			employee.getSalary();
			employee.getName();
			repo.save(employee);
			return "Employee Updated Successfully...";
		}
		else {
			return "Employee Not Found with ID:"+id;
		}
	}
	
	public String deleteEmployee(int id) {
		if(repo.existsById(id)) {
			repo.deleteById(id);
			return "Employee Deleted Successfully...";
		}
		else {
			return "Employee Not Found with ID:"+id;
		}
	}
	
	public Employee getEmployeeById(int id) {
		return repo.findById(id)
				.orElseThrow(() -> new
                       EmployeeNotFoundException("employee not found with id.."+id));
	}
	
}