import { Injectable, signal } from '@angular/core';

export interface Message {
  id: number;
  text: string;
  sender: string;
  timestamp: Date;
}

@Injectable({
  providedIn: 'root',
})
export class Chatservice {
  private messageIdCounter = 0;
  messages = signal<Message[]>([]);

  addMessage(text: string, sender: string): void {
    if (text.trim()) {
      const newMessage: Message = {
        id: this.messageIdCounter++,
        text,
        sender,
        timestamp: new Date(),
      };
      this.messages.update((msgs) => [...msgs, newMessage]);
    }
  }

  clearMessages(): void {
    this.messages.set([]);
  }
}
