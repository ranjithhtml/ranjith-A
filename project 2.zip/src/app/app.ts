import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chatservice } from './chatservice';

@Component({
  selector: 'app-root',
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
  providers: [Chatservice],
})
export class App {
  protected readonly title = signal('Chat Application');
  protected newMessage = signal('');
  protected currentUser = signal('ranjith');
  protected readonly users = ['ranjith', 'tamil'];
  constructor(protected chatService: Chatservice) {}

  sendMessage(): void {
    const message = this.newMessage().trim();
    if (message) {
      this.chatService.addMessage(message, this.currentUser());
      this.newMessage.set('');
    }
  }

  switchUser(): void {
    const currentUser = this.currentUser();
    this.currentUser.set(currentUser === 'ranjith' ? 'tamil' : 'ranjith');
  }

  clearChat(): void {
    this.chatService.clearMessages();
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }
}
