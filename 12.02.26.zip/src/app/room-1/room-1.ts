import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ComponentAc } from '../acservice';

@Component({
  selector: 'app-room-1',
  imports: [],
  templateUrl: './room-1.html',
  styleUrl: './room-1.css',
})
export class Room1 {
message = '';
constructor(private acService: ComponentAc){

} 
  // 👆 AC is injected here (DI)
onAc() {
    this.message = this.acService.turnOn();
  }
offAc() {
    this.message = this.acService.turnOff();
  }
}
