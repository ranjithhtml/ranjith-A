import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ComponentAc {
  
  turnOn() {
    return 'AC is ON ++++';
  }
turnOff() {
    return 'AC is OFF ----';
  }
}
