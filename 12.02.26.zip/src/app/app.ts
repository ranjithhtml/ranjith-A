import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Room1 } from './room-1/room-1';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Room1,CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('room-ac');
}
