package com.example.demo;
	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.*;
	import org.springframework.web.bind.annotation.*;

	@RestController
	@RequestMapping("/students")
	public class StudentController5 {

	    @Autowired
	    private StudentRepository repo;

	    // POST – Create Student
	    @PostMapping
	    public ResponseEntity<Student> addStudent(@RequestBody Student student) {
	        return new ResponseEntity<>(repo.save(student), HttpStatus.CREATED);
	    }

	    // GET – Get All Students
	    @GetMapping
	    public ResponseEntity<List<Student>> getAllStudents() {
	        return new ResponseEntity<>(repo.findAll(), HttpStatus.OK);
	    }

		

	    // DELETE – Delete Student
	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> deleteStudent(@PathVariable int id) {
	        repo.deleteById(id);
	        return new ResponseEntity<>("Deleted successfully", HttpStatus.OK);
	    }
	}


