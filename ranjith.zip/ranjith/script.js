function validateform() {
    var username= document.getElementById("username").value;
    var password= document.getElementById("password").value;
   
    if (username === "ranjith" && password === "12345") {
        alert("Username and password are correct");
        window.location.href="http://www.fb.com"
        return true;   // allow form submission
    } else {
        alert("Username or password is incorrect");
        return false;
    }
    if (username==""){
        alert(" user name is not correct ");
        return false;
    }
    if(password ==""){
        alert(" password is not correct ");
        return false;
    }
}
