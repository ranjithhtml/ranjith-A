import { Component, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from './EmployeeService';

@Component({
  selector: 'app-root',
  imports: [CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit {
  protected readonly title = signal('anand-frontend');
  employees: any[] = [];

constructor(private empService: EmployeeService) {}
ngOnInit() {
    this.empService.getEmployees().subscribe(data => {
        this.employees = data;
        
      });
      
      }
      
   }          


