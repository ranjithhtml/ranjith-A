package pen;

class Child
{

	void sugar()
	{
		System.out.println(" i am having sugar ");
	}
}

class father extends Child
{
	void bp()
	{

		System.out.println("I am having BP");
	}
}

public class GrandFather  extends father {
	

	
public static void main(String[] args) {
	GrandFather cc = new GrandFather();
	cc.bp();
	cc.sugar();
}
}



