package pen;

// method overloading/ method overriding

//same name of the method with  diffi in same class	
//same nan of  a method with same parameter in ssub classs

abstract class Abc
{
abstract  void m1() ;
}


public class Child3 extends Abc {
void m1()
{
	System.out.println("method m1");
}

public static void main(String[] args) {
Child3  xy = new Child3();
xy.m1();


}
}

//  OOPS
// inheriance , encpsulation , polymorphism, abstraction	
//  OOPS
// inheriance , encpsulation , polymorphism, abstraction

//  OOPS
// inheriance , encpsulation , polymorphism, abstraction