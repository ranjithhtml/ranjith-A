package pen;


public class math {
	void add() {
		int a=4;
		int b=2;
		int c =a+b;
		System.out.println(" addition "+ c);
	}
	void sub() {
		int a=20;
		int b=04;
		int c =a-b;
		System.out.println(" subtraction "+ c);
	}
	void mul() {
		int a=4;
		int b=20;
		int c =a*b;
		System.out.println(" multification "+ c);
	}
	void div() {
		int a=4;
		int b=40;
		int c =a%b;
		System.out.println(" division "+ c);
		System.out.println("");
	}

	
	public static void main(String[] args) {
	System.out.println(" hello world ");
	System.out.println("");
	math a = new math();
	a.add();
    a.sub();
    a.mul();
    a.div();
    System.out.println(" thank you maths ");

	}

}
