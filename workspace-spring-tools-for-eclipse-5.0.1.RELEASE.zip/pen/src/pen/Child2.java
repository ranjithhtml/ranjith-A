package pen;

//method overloading/ method overriding

//same name of the method with  diffi in same class	
//same nan of  a method with same parameter in ssub classs

class Abcd
{
	void m1()
	{
		System.out.println("method m1 fsdasdfsdfaro paarent clas");
	}
}

public class Child2 extends Abcd {
	void m1()
	{
		System.out.println("method m1 fsdrent clas");
		super.m1();
	}
	
public static void main(String[] args) {
	Child2  xy = new Child2();
xy.m1();

	
}
}