package pen;

public class simple {
	void add() {
		System.out.println("add"+(2+4));
	}

	public static void main(String[] args) {
		simple s=new simple();
		s.add();
	}

}
 