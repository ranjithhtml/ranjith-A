package pen;

public class pen {
	static String name= "Reynolds";
	int price = 5;
	
	public pen(String message) {
		System.out.println(message);
	}
	public pen() {
		System.out.println("Pen1 Writing....");
	}
	
	public void write() {
		System.out.println("Writing....");
	}
	
public static void main(String args[]) {
	System.out.println("Starting");
	pen pen1= new pen();
	pen pen2=new pen("dededede");
	pen1.write();
	pen2.write();
	
}
}
