package pen;

public class demo {
	
	public demo() {
	
		System.out.println(" Hellow constructor "+(2+2));
	}
	
   void add()
   {
	   System.out.println(" Hellow world "+(2+2));
   }
	
   void sub()
   {
	   System.out.println(" Hellow world "+(2-2));
   }
	
public static void main(String[] args) {
	demo  cc = new demo();
	cc.add();
 	cc.sub();
}
}
