package pen;

abstract class ATM1 {
	abstract void withdraw();

	abstract void deposite();
}

abstract class Abcd1 extends ATM1 {

	@Override
	void withdraw() {
		System.out.println("asdfasdf");
	}

}

public class Child5 extends Abcd1 {
	@Override
	void deposite() {

		System.out.println("ahello wrld");
	}

	public static void main(String[] args) {
		Child5 xy = new Child5();
		xy.withdraw();
		xy.deposite();
	}

}

// OOPS
// inheriance , encpsulation , polymorphism, abstraction



// OOPS
// inheriance , encpsulation , polymorphism, abstraction