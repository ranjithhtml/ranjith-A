package pen;


abstract class ATM {
	abstract void withdraw();

	abstract void deposite();

}

public class Child4 extends ATM{

	void withdraw() {
		System.out.println("hello atm");
	}

	void deposite() {
		System.out.println("hello indian bank");
	}

	public static void main(String[] args) {
		Child4 xy = new Child4();
xy.withdraw();
xy.deposite();
	}
}

