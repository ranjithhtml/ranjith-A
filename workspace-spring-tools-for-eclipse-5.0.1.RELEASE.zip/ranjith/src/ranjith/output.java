package ranjith;

public class output {
	void method() {
		System.out.println("hello");
	}

	public static void main(String[] args) {
		System.out.println("hi");
		output c = new output();
        c.method();
	}

}
