package ranjith;

public class Test {
public void main(String[] args) {
	
		int a[] = {10, 20, 30};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		try {
	    System.out.println(a[3]);
	}
	 catch (Exception e)
	{
		System.out.println("hello"+e);
	}
		try {
	    System.out.println(10/0);
		}
	  catch (Exception e) {
		  System.out.println("welcom"+e);
	}
	    System.out.println("hello");
	    System.out.println("hello");
	    System.out.println("hello");
	
	
	System.out.println("sfdfyhtffgf");
}
}
