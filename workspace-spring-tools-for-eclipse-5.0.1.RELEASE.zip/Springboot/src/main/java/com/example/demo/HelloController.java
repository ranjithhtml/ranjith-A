package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
     @GetMapping("/police")
	 public  String sayaHello(){
	    	return "I am happpy boy";
	    }
}
