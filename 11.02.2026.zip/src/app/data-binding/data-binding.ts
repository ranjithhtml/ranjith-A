import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  imports: [FormsModule],
  templateUrl: './data-binding.html',
  styleUrl: './data-binding.css',
})
export class databinding {
  // interpolation
  name="tamilnadu";
  //property binding
  isDisabled =false;
  // event binding
  enableButton(){
    this.isDisabled=true;
  }
  //two way binding
  username='';
  showalert(){
    alert('Hello '+ this.username)
  }
}

