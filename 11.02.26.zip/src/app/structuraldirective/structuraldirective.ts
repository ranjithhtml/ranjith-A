import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-structuraldirective',
  imports: [CommonModule],
  templateUrl: './structuraldirective.html',
  styleUrl: './structuraldirective.css',
})
export class Structuraldirective {

  
  // ====== ngIf ======
  isLoggedIn: boolean = false;

  // ====== ngFor ======
  courses: string[] = ['Angular', 'React', 'Vue', 'Node'];

  // ====== ngSwitch ======
  role: string = 'admin';

  // ====== Methods ======
  login() {
    this.isLoggedIn = true;
  }

  logout() {
    this.isLoggedIn = false;
  }

  setRole(newRole: string) {
    this.role = newRole;
  }


}
