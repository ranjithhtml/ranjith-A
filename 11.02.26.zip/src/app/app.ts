import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Test } from './test/test';
import { Structuraldirective } from './structuraldirective/structuraldirective';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Test,Structuraldirective],
  standalone:true,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('directivedemo');
}
