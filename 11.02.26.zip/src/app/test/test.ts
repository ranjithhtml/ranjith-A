import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  imports: [],
  templateUrl: './test.html',
  styleUrl: './test.css',
})
export class Test {

//string interpolation
name:string = "Ranjith";
course:string="English";
fees:number=10000;

  //property binding
  isDisabled =false;

  // event binding
  enableButton(){
    this.isDisabled=true;
  }
  //two way binding
  username='';
  showalert(){
    alert('Hello '+ this.username)
  }

}
