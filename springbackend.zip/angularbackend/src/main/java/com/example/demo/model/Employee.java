package com.example.demo.model;

public class Employee {
	private int id;
	private String name;
	
	
	
	
 
  public Employee(int id, String name ) {
	  this.id = id;
	  this.name = name;
		// TODO Auto-generated constructor stub
	}
  public int getId() {
	  return id;
	  }
  public String getName() {
	  return name;
	  }
  }

