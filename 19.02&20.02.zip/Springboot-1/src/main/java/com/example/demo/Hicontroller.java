package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class Hicontroller {
    @GetMapping("/ranjith")
	public String SayHi() {
		return " i am from tamilnadu";
		
	}

}
