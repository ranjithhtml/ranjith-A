package Test;

@Component
public class car {
	public Engine engine;
	public car(Engine engine) {
		this.engine = engine;
	}
public String drive() {
	return engine.start();
}
}
